//
//  PushFromBottom.h
//  SwitchControllerAnimation
//
//  Created by  www.6dao.cc on 16/6/14.
//  Copyright © 2016年 ledao. All rights reserved.
//

#import "WHBaseAnimationTransitioning.h"

@interface PushFromBottom : WHBaseAnimationTransitioning

#pragma mark - 真正实现 push, pop 动画的方法, 具体实现交给子类
- (void)push:(id<UIViewControllerContextTransitioning>)transitionContext;
- (void)pop:(id<UIViewControllerContextTransitioning>)transitionContext;

@end
