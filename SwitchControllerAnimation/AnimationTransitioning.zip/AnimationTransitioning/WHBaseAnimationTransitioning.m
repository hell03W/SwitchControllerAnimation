//
//  WHBaseAnimationTransitioning.m
//  SwitchControllerAnimation
//
//  Created by  www.6dao.cc on 16/6/14.
//  Copyright © 2016年 ledao. All rights reserved.
//

#import "WHBaseAnimationTransitioning.h"

/// 默认动画执行时间间隔
const static NSTimeInterval WHAnimationTransitioningDuration = 0.75;

@interface WHBaseAnimationTransitioning ()

@property (nonatomic, assign) NSTimeInterval duration;
@property (nonatomic, assign) WHAnimationTransitioning transitionType;

@end

@implementation WHBaseAnimationTransitioning

- (instancetype)init {
    
    if (self = [super init]) {
        self.duration = WHAnimationTransitioningDuration;
        self.transitionType = WHAnimationTransitioningPush;
    }
    return self;
}

+ (instancetype)transitionWithType:(WHAnimationTransitioning)transitionType {
    
    return [self transitionWithType:transitionType duration:WHAnimationTransitioningDuration];
}

+ (instancetype)transitionWithType:(WHAnimationTransitioning)transitionType
                          duration:(NSTimeInterval)duration {
    
    WHBaseAnimationTransitioning *animationTransitioning = [[WHBaseAnimationTransitioning alloc] init];
    animationTransitioning.duration = duration;
    animationTransitioning.transitionType = transitionType;
    
    return animationTransitioning;
}


- (void)push:(id<UIViewControllerContextTransitioning>)transitionContext {NSLog(@"push controller");}
- (void)pop:(id<UIViewControllerContextTransitioning>)transitionContext {NSLog(@"pop controller");}
- (void)pushEnded {}
- (void)popEnded {}



#pragma mark - UIViewControllerAnimatedTransitioning
- (NSTimeInterval)transitionDuration:(nullable id <UIViewControllerContextTransitioning>)transitionContext {
    
    return self.duration;
}

- (void)animateTransition:(id <UIViewControllerContextTransitioning>)transitionContext {
    
    if (self.transitionType == WHAnimationTransitioningPush) {
        [self push:transitionContext];
    }
    else if (self.transitionType == WHAnimationTransitioningPop) {
        [self pop:transitionContext];
    }
}


- (void)animationEnded:(BOOL) transitionCompleted {

    if (!transitionCompleted) return;

    if (self.transitionType == WHAnimationTransitioningPush) {
        [self pushEnded];
    }
    else if (self.transitionType == WHAnimationTransitioningPop) {
        [self popEnded];
    }
}

@end
